using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class DebugText : MonoBehaviour
{
    [SerializeField] PlayerControlsPhys _playerControls;
    [SerializeField]TextMeshProUGUI _text;

    private void Update()
    {
        Vector3 velocity = _playerControls.GetVelocity();
        _text.text = $"X:{velocity.x}{Environment.NewLine}Y:{velocity.y}{Environment.NewLine}Z:{velocity.z}{Environment.NewLine}Mag:{velocity.magnitude}";
    }
}
