using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public Transform CurrentRespawnPoint;

    private int _partOfLevel;
    [SerializeField] private List<int> _numOfLights;
    [SerializeField] private float lightsTurningOnSpeed =1.0f;

    public UnityEvent<int, int> NotifyLights;
    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Debug.LogError("TOO MANY GAME MANAGERS");
    }
    private void Start()
    {
        StartCoroutine(ChangeLevelPart(0));
    }

    public IEnumerator ChangeLevelPart(int newPart)
    {
        _partOfLevel = newPart;
        for(int i =0; i< _numOfLights[newPart]; i++)
        {
            yield return new WaitForSeconds(lightsTurningOnSpeed);
            NotifyLights?.Invoke(newPart, i);
        }
    }

}
